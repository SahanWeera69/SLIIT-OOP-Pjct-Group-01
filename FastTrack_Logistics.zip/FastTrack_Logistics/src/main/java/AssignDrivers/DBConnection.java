/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AssignDrivers;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author User
 */
public class DBConnection {
    
    private static final String URL = "jdbc:mysql://localhost:3306/fasttrack";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 

    
    public static Connection getConnection() {
        Connection connection = null;
        try {
           
            Class.forName("com.mysql.cj.jdbc.Driver");

          
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database connection established successfully!"); 

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL JDBC Driver not found!\n" + e.getMessage(),
                                          "Database Connection Error", JOptionPane.ERROR_MESSAGE);
            System.err.println("JDBC Driver not found: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database!\n" + e.
                                          getMessage() + "\nEnsure XAMPP MySQL is running and credentials are correct.",
                                          "Database Connection Error", JOptionPane.ERROR_MESSAGE);
            System.err.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
        return connection; 
    }

   
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error closing database connection!\n" + e.getMessage(),
                                              "Database Error", JOptionPane.ERROR_MESSAGE);
                System.err.println("Error closing connection: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    
    
    
}
