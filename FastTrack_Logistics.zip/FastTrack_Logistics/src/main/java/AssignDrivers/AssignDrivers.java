/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package AssignDrivers;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import javax.swing.event.ListSelectionEvent; 
import javax.swing.event.ListSelectionListener; 

public class AssignDrivers extends javax.swing.JFrame {

   public AssignDrivers() {
    initComponents();

   
    tblShipments.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent evt) {
           
            if (!evt.getValueIsAdjusting()) {
                int selectedRow = tblShipments.getSelectedRow();
                if (selectedRow != -1) { 
                   
                    displayShipmentDetails(selectedRow);
                } else {
                   
                    txtDetailShipmentId.setText("");
                    txtDetailCustomer.setText("");
                    txtDetailOrigin.setText("");
                    txtDetailDestination.setText("");
                    txtDetailStatus.setText("");
                    txtDetailEstDelivery.setText("");
                }
            }
        }
    });

   
    loadShipments("");          
    loadAvailableDrivers();     
};
   
   
   
private void loadShipments(String searchText) {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    DefaultTableModel model = (DefaultTableModel) tblShipments.getModel();
    model.setRowCount(0); 

    String sql = "SELECT shipment_id, customer_name, destination_address, status FROM assign";
    if (searchText != null && !searchText.trim().isEmpty()) {
       
        sql += " WHERE shipment_id LIKE ? OR customer_name LIKE ? OR destination_address LIKE ?";
    }
    
    sql += " ORDER BY shipment_id ASC";

    try {
        con = DBConnection.getConnection(); 
        if (con == null) return; 

        pst = con.prepareStatement(sql);

        if (searchText != null && !searchText.trim().isEmpty()) {
            String searchPattern = "%" + searchText + "%";
            pst.setString(1, searchPattern);
            pst.setString(2, searchPattern); 
            pst.setString(3, searchPattern); 
        }

        rs = pst.executeQuery(); 

        while (rs.next()) {
            
            model.addRow(new Object[]{
                rs.getString("shipment_id"),
                rs.getString("customer_name"),
                rs.getString("destination_address"),
                rs.getString("status")
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading shipments: " + e.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } finally {
       
        DBConnection.closeConnection(con); 
        try { if (pst != null) pst.close(); } catch (SQLException e) { }
        try { if (rs != null) rs.close(); } catch (SQLException e) {  }
    };
}


private void loadAvailableDrivers() {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
   
    DefaultListModel<String> driverListModel = new DefaultListModel<>();
    lstAvailableDrivers.setModel(driverListModel);

    String sql = "SELECT driver_id, driver_name FROM drivers WHERE availability_status = 'Available'";
    sql += " ORDER BY driver_name ASC";

    try {
        con = DBConnection.getConnection();
        if (con == null) return;

        pst = con.prepareStatement(sql);
        rs = pst.executeQuery();

        while (rs.next()) {
           
            driverListModel.addElement(rs.getString("driver_id") + " - " + rs.getString("driver_name"));
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading available drivers: " + e.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } finally {
        DBConnection.closeConnection(con);
        try { if (pst != null) pst.close(); } catch (SQLException e) {  }
        try { if (rs != null) rs.close(); } catch (SQLException e) { }
    }
}



private void displayShipmentDetails(int selectedRow) {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

   
    String shipmentId = tblShipments.getModel().getValueAt(
                            tblShipments.convertRowIndexToModel(selectedRow), 0).toString();

    String sql = "SELECT shipment_id, customer_name, origin_address, destination_address, status, estimated_delivery_date " +
                 "FROM assign WHERE shipment_id = ?";

    try {
        con = DBConnection.getConnection();
        if (con == null) return;

        pst = con.prepareStatement(sql);
        pst.setString(1, shipmentId);
        rs = pst.executeQuery();

        if (rs.next()) { 
            txtDetailShipmentId.setText(rs.getString("shipment_id"));
            txtDetailCustomer.setText(rs.getString("customer_name"));
            txtDetailOrigin.setText(rs.getString("origin_address"));
            txtDetailDestination.setText(rs.getString("destination_address"));
            txtDetailStatus.setText(rs.getString("status"));
            
            java.sql.Date estDate = rs.getDate("estimated_delivery_date");
            txtDetailEstDelivery.setText(estDate != null ? estDate.toString() : "N/A"); 
        } else {
            
            JOptionPane.showMessageDialog(this, "Shipment details not found for ID: " + shipmentId + " in database.",
                                          "Data Error", JOptionPane.WARNING_MESSAGE);
            
            txtDetailShipmentId.setText("");
            txtDetailCustomer.setText("");
            txtDetailOrigin.setText("");
            txtDetailDestination.setText("");
            txtDetailStatus.setText("");
            txtDetailEstDelivery.setText("");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching shipment details: " + e.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } finally {
        DBConnection.closeConnection(con);
        try { if (pst != null) pst.close(); } catch (SQLException e) {  }
        try { if (rs != null) rs.close(); } catch (SQLException e) {  }
    }
};
    
    
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        pnlMainContent = new javax.swing.JPanel();
        pnlShipmentSection = new javax.swing.JPanel();
        pnlShipmentSearch = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtShipmentSearch = new javax.swing.JTextField();
        btnSearchShipment = new javax.swing.JButton();
        btnRefreshShipments = new javax.swing.JButton();
        scpShipments = new javax.swing.JScrollPane();
        tblShipments = new javax.swing.JTable();
        pnlShipmentDetails = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtDetailShipmentId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtDetailCustomer = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtDetailOrigin = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDetailDestination = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtDetailStatus = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtDetailEstDelivery = new javax.swing.JTextField();
        pnlDriverSection = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstAvailableDrivers = new javax.swing.JList<>();
        pnlDriverActions = new javax.swing.JPanel();
        btnCloseForm = new javax.swing.JButton();
        btnClearDriverSelection = new javax.swing.JButton();
        btnAssignDrivers = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Assign Drivers to Shipments");
        setResizable(false);

        pnlHeader.setBackground(new java.awt.Color(231, 76, 60));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("DialogInput", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Assign Drivers to Shipments");
        pnlHeader.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(481, 5, -1, -1));

        jButton1.setBackground(new java.awt.Color(231, 76, 60));
        jButton1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("🔙");
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        pnlHeader.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 80, 40));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlMainContent.setBackground(new java.awt.Color(255, 255, 255));
        pnlMainContent.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15));
        pnlMainContent.setLayout(new java.awt.GridLayout(1, 2, 15, 0));

        pnlShipmentSection.setBackground(new java.awt.Color(255, 255, 204));
        pnlShipmentSection.setLayout(new java.awt.BorderLayout());

        pnlShipmentSearch.setBackground(new java.awt.Color(255, 255, 255));
        pnlShipmentSearch.setBorder(javax.swing.BorderFactory.createTitledBorder("Find Shipment"));
        pnlShipmentSearch.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel2.setText("Search Shipment ID/Customer:");
        pnlShipmentSearch.add(jLabel2);

        txtShipmentSearch.setPreferredSize(new java.awt.Dimension(150, 22));
        txtShipmentSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtShipmentSearchActionPerformed(evt);
            }
        });
        pnlShipmentSearch.add(txtShipmentSearch);

        btnSearchShipment.setText("Serach");
        btnSearchShipment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchShipmentActionPerformed(evt);
            }
        });
        pnlShipmentSearch.add(btnSearchShipment);

        btnRefreshShipments.setText("Reset");
        btnRefreshShipments.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshShipmentsActionPerformed(evt);
            }
        });
        pnlShipmentSearch.add(btnRefreshShipments);

        pnlShipmentSection.add(pnlShipmentSearch, java.awt.BorderLayout.PAGE_START);

        tblShipments.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Shipment ID", "Customer Name", "Destination", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblShipments.setRowHeight(25);
        scpShipments.setViewportView(tblShipments);

        pnlShipmentSection.add(scpShipments, java.awt.BorderLayout.CENTER);

        pnlShipmentDetails.setBackground(new java.awt.Color(255, 255, 255));
        pnlShipmentDetails.setBorder(javax.swing.BorderFactory.createTitledBorder("Selected Shipment Details"));

        jLabel3.setText("Shipment ID:");

        txtDetailShipmentId.setEditable(false);
        txtDetailShipmentId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDetailShipmentIdActionPerformed(evt);
            }
        });

        jLabel4.setText("Customer:");

        txtDetailCustomer.setEditable(false);

        jLabel5.setText("Origin:");

        txtDetailOrigin.setEditable(false);

        jLabel6.setText("Destination:");

        txtDetailDestination.setEditable(false);

        jLabel7.setText("Current Status:");

        txtDetailStatus.setEditable(false);

        jLabel8.setText("Est. Delivery:");

        txtDetailEstDelivery.setEditable(false);

        javax.swing.GroupLayout pnlShipmentDetailsLayout = new javax.swing.GroupLayout(pnlShipmentDetails);
        pnlShipmentDetails.setLayout(pnlShipmentDetailsLayout);
        pnlShipmentDetailsLayout.setHorizontalGroup(
            pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlShipmentDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlShipmentDetailsLayout.createSequentialGroup()
                        .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(28, 28, 28)
                        .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDetailCustomer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 535, Short.MAX_VALUE)
                            .addComponent(txtDetailOrigin, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtDetailDestination)
                            .addComponent(txtDetailShipmentId)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlShipmentDetailsLayout.createSequentialGroup()
                        .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlShipmentDetailsLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(pnlShipmentDetailsLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(30, 30, 30)))
                        .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDetailEstDelivery, javax.swing.GroupLayout.DEFAULT_SIZE, 535, Short.MAX_VALUE)
                            .addComponent(txtDetailStatus))))
                .addContainerGap())
        );
        pnlShipmentDetailsLayout.setVerticalGroup(
            pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlShipmentDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDetailShipmentId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDetailCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDetailOrigin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtDetailDestination, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDetailStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlShipmentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtDetailEstDelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pnlShipmentSection.add(pnlShipmentDetails, java.awt.BorderLayout.PAGE_END);

        pnlMainContent.add(pnlShipmentSection);

        pnlDriverSection.setBackground(new java.awt.Color(255, 255, 255));
        pnlDriverSection.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("")));
        pnlDriverSection.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Available Drivers"));

        lstAvailableDrivers.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Driver 001 (Available)", "Driver 002 (On Duty)", " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstAvailableDrivers);

        pnlDriverSection.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pnlDriverActions.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCloseForm.setBackground(new java.awt.Color(255, 153, 153));
        btnCloseForm.setText("Close");
        btnCloseForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseFormActionPerformed(evt);
            }
        });
        pnlDriverActions.add(btnCloseForm);

        btnClearDriverSelection.setBackground(new java.awt.Color(153, 204, 255));
        btnClearDriverSelection.setText("Clear Driver Selection");
        btnClearDriverSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearDriverSelectionActionPerformed(evt);
            }
        });
        pnlDriverActions.add(btnClearDriverSelection);

        btnAssignDrivers.setBackground(new java.awt.Color(153, 255, 153));
        btnAssignDrivers.setText("Assign Drivers");
        btnAssignDrivers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignDriversActionPerformed(evt);
            }
        });
        pnlDriverActions.add(btnAssignDrivers);

        pnlDriverSection.add(pnlDriverActions, java.awt.BorderLayout.PAGE_END);

        pnlMainContent.add(pnlDriverSection);

        getContentPane().add(pnlMainContent, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtShipmentSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtShipmentSearchActionPerformed
       
loadShipments(txtShipmentSearch.getText());
    }//GEN-LAST:event_txtShipmentSearchActionPerformed

    private void btnSearchShipmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchShipmentActionPerformed
loadShipments(txtShipmentSearch.getText()); 
    }//GEN-LAST:event_btnSearchShipmentActionPerformed

    private void txtDetailShipmentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDetailShipmentIdActionPerformed
        //  no action needed 
    }//GEN-LAST:event_txtDetailShipmentIdActionPerformed

    private void btnRefreshShipmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshShipmentsActionPerformed
txtShipmentSearch.setText("");  
loadShipments("");             
tblShipments.clearSelection();  
    }//GEN-LAST:event_btnRefreshShipmentsActionPerformed

    private void btnAssignDriversActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignDriversActionPerformed
      Connection con = null;
PreparedStatement insertAssignmentPst = null;
PreparedStatement updateShipmentPst = null;
PreparedStatement updateDriverPst = null;

int selectedShipmentViewRow = tblShipments.getSelectedRow();
java.util.List<String> selectedDriversList = lstAvailableDrivers.getSelectedValuesList();

if (selectedShipmentViewRow == -1) {
    JOptionPane.showMessageDialog(this, "Please select a shipment first.", "Missing Selection", JOptionPane.WARNING_MESSAGE);
    return;
}
if (selectedDriversList.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Please select at least one driver to assign.", "Missing Selection", JOptionPane.WARNING_MESSAGE);
    return;
}


String shipmentId = tblShipments.getModel().getValueAt(
                        tblShipments.convertRowIndexToModel(selectedShipmentViewRow), 0).toString();

try {
    con = DBConnection.getConnection();
    if (con == null) return;

   
    con.setAutoCommit(false);

    
    String insertSql = "INSERT INTO shipment_assignments (shipment_id, driver_id, assignment_status) VALUES (?, ?, 'Active')";
    insertAssignmentPst = con.prepareStatement(insertSql);

    for (String driverEntry : selectedDriversList) {
        String driverId = driverEntry.split(" - ")[0]; 
        insertAssignmentPst.setString(1, shipmentId);
        insertAssignmentPst.setString(2, driverId);
        insertAssignmentPst.addBatch(); 
    }
    insertAssignmentPst.executeBatch(); 

    
    String updateShipmentSql = "UPDATE assign SET status = 'Assigned' WHERE shipment_id = ?";
    updateShipmentPst = con.prepareStatement(updateShipmentSql);
    updateShipmentPst.setString(1, shipmentId);
    updateShipmentPst.executeUpdate();

    
    String updateDriverSql = "UPDATE drivers SET availability_status = 'On Duty' WHERE driver_id = ?";
    updateDriverPst = con.prepareStatement(updateDriverSql);
    for (String driverEntry : selectedDriversList) {
        String driverId = driverEntry.split(" - ")[0];
        updateDriverPst.setString(1, driverId);
        updateDriverPst.addBatch();
    }
    updateDriverPst.executeBatch();

    con.commit(); 

    JOptionPane.showMessageDialog(this, "Shipment " + shipmentId + " successfully assigned to selected drivers!",
                                  "Assignment Success", JOptionPane.INFORMATION_MESSAGE);

    
    loadShipments(""); 
    loadAvailableDrivers(); 
    tblShipments.clearSelection(); 
    lstAvailableDrivers.clearSelection();
    txtShipmentSearch.setText(""); 

} catch (SQLException e) {
    
    try {
        if (con != null) con.rollback();
    } catch (SQLException rbEx) {
        System.err.println("Rollback failed: " + rbEx.getMessage());
        rbEx.printStackTrace();
    }
    JOptionPane.showMessageDialog(this, "Error assigning drivers: " + e.getMessage() + "\nAssignment rolled back.",
                                  "Database Error", JOptionPane.ERROR_MESSAGE);
    e.printStackTrace();
} finally {
   
    DBConnection.closeConnection(con);
    try { if (insertAssignmentPst != null) insertAssignmentPst.close(); } catch (SQLException e) {  }
    try { if (updateShipmentPst != null) updateShipmentPst.close(); } catch (SQLException e) {  }
    try { if (updateDriverPst != null) updateDriverPst.close(); } catch (SQLException e) {  }
}
    }//GEN-LAST:event_btnAssignDriversActionPerformed

    private void btnClearDriverSelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearDriverSelectionActionPerformed
    lstAvailableDrivers.clearSelection(); 
    }//GEN-LAST:event_btnClearDriverSelectionActionPerformed

    private void btnCloseFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseFormActionPerformed
       this.dispose(); 
    }//GEN-LAST:event_btnCloseFormActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AssignDrivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AssignDrivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AssignDrivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AssignDrivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AssignDrivers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssignDrivers;
    private javax.swing.JButton btnClearDriverSelection;
    private javax.swing.JButton btnCloseForm;
    private javax.swing.JButton btnRefreshShipments;
    private javax.swing.JButton btnSearchShipment;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstAvailableDrivers;
    private javax.swing.JPanel pnlDriverActions;
    private javax.swing.JPanel pnlDriverSection;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlMainContent;
    private javax.swing.JPanel pnlShipmentDetails;
    private javax.swing.JPanel pnlShipmentSearch;
    private javax.swing.JPanel pnlShipmentSection;
    private javax.swing.JScrollPane scpShipments;
    private javax.swing.JTable tblShipments;
    private javax.swing.JTextField txtDetailCustomer;
    private javax.swing.JTextField txtDetailDestination;
    private javax.swing.JTextField txtDetailEstDelivery;
    private javax.swing.JTextField txtDetailOrigin;
    private javax.swing.JTextField txtDetailShipmentId;
    private javax.swing.JTextField txtDetailStatus;
    private javax.swing.JTextField txtShipmentSearch;
    // End of variables declaration//GEN-END:variables
}
