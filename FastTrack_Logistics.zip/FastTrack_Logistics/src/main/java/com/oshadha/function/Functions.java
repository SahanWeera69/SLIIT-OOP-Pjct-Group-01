package com.oshadha.function;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicComboBoxUI;


import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.AbstractButton;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.JTableHeader;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.BorderFactory;
import javax.swing.JScrollBar;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Container;

import javax.swing.border.Border;
import java.awt.Dimension;

import java.awt.RenderingHints;

public class Functions extends javax.swing.JPanel {
    
    public Functions() {
        initComponents();
        loadTable();
        styleButtons();
        
        styleTextFields(jTextField1, jTextField2, jTextField3, jTextField4, jTextField5);
        addHintToTextField(jTextField1, "Enter product ID...");
        addHintToTextField(jTextField2, "Enter package location...");
        addHintToTextField(jTextField3, "Enter ETA...");
        addHintToTextField(jTextField4, "Enter Delay...");
        addHintToTextField(jTextField5, "Search product ID...");
        
        styleComboBox(jComboBox1);
        styleTable(jTable2);
        styleScrollBar(jScrollPane2.getVerticalScrollBar());
        styleScrollBar(jScrollPane2.getHorizontalScrollBar());
        
        jButton1.setBorderPainted(false);
        jButton1.setFocusPainted(false);
        jButton1.setContentAreaFilled(true);
        jButton1.setBorder(BorderFactory.createEmptyBorder());
        
        jButton2.setBorderPainted(false);
        jButton2.setFocusPainted(false);
        jButton2.setContentAreaFilled(true);
        jButton2.setBorder(BorderFactory.createEmptyBorder());
        
        jButton3.setBorderPainted(false);
        jButton3.setFocusPainted(false);
        jButton3.setContentAreaFilled(true);
        jButton3.setBorder(BorderFactory.createEmptyBorder());
        
        jButton4.setBorderPainted(false);
        jButton4.setFocusPainted(false);
        jButton4.setContentAreaFilled(true);
        jButton4.setBorder(BorderFactory.createEmptyBorder());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Product ID");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Package Location");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Estimatetd Delivery Time");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Delays");

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "In Transit", "Delivered", "Failed" }));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Search product");

        jTextField5.setToolTipText("");

        jButton4.setText("Search");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jScrollPane2.setBackground(new java.awt.Color(255, 255, 255));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Package Location", "ETA", "Status", "Delays"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(90, 90, 90)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 731, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addComponent(jButton4))
                    .addComponent(jLabel5)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(101, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(39, 39, 39)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

        private void loadTable() {
            DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
            model.setRowCount(0);

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "SELECT * FROM tracking";
                PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("product_id"),
                        rs.getString("location"),
                        rs.getString("estimated_delivery_time"),
                        rs.getString("status"),
                        rs.getString("delays")
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        private void styleScrollBar(JScrollBar scrollBar) {
            scrollBar.setUI(new BasicScrollBarUI() {

                private final Dimension zeroDim = new Dimension(0, 0);

                @Override
                protected JButton createDecreaseButton(int orientation) {
                    return createZeroButton();
                }

                @Override
                protected JButton createIncreaseButton(int orientation) {
                    return createZeroButton();
                }

                private JButton createZeroButton() {
                    JButton button = new JButton();
                    button.setPreferredSize(zeroDim);
                    button.setMinimumSize(zeroDim);
                    button.setMaximumSize(zeroDim);
                    button.setVisible(false);
                    return button;
                }

                @Override
                protected void configureScrollBarColors() {
                    this.thumbColor = new Color(200, 200, 200); // light gray thumb
                    this.trackColor = new Color(245, 245, 245); // very light track
                }

                @Override
                protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    g2.setColor(thumbColor);
                    g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 12, 12);

                    g2.dispose();
                }

                @Override
                protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
                    g.setColor(trackColor);
                    g.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
                }
            });

            scrollBar.setPreferredSize(new Dimension(10, 0)); // thinner bar
            scrollBar.setOpaque(false);
        }

        
        private void styleTextFields(JTextField... fields) {
            for (JTextField field : fields) {
                field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                field.setForeground(Color.DARK_GRAY);
                field.setBackground(Color.WHITE);
                field.setCaretColor(Color.BLACK); // cursor color
                field.setOpaque(true);

                // Border with padding
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true),  // rounded border
                    BorderFactory.createEmptyBorder(5, 10, 5, 10)  // padding inside
                ));
            }
        }
        
        private void addHintToTextField(JTextField textField, String hintText) {
            textField.setText(hintText);
            textField.setForeground(Color.GRAY);

            textField.addFocusListener(new java.awt.event.FocusAdapter() {
                @Override
                public void focusGained(java.awt.event.FocusEvent evt) {
                    if (textField.getText().equals(hintText)) {
                        textField.setText("");
                        textField.setForeground(Color.BLACK);
                    }
                }

                @Override
                public void focusLost(java.awt.event.FocusEvent evt) {
                    if (textField.getText().isEmpty()) {
                        textField.setForeground(Color.GRAY);
                        textField.setText(hintText);
                    }
                }
            });
        }
        
        private void styleComboBox(JComboBox comboBox) {
            comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            comboBox.setForeground(Color.DARK_GRAY);
            comboBox.setBackground(Color.WHITE);
            comboBox.setOpaque(true);
            comboBox.setFocusable(false);
            comboBox.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Remove default border and apply custom rounded border
            /*comboBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
            ));*/
            comboBox.setBorder(
                BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true)
            );

            // Custom UI for arrow button and cleaner look
            comboBox.setUI(new BasicComboBoxUI() {
                @Override
                protected JButton createArrowButton() {
                    JButton arrow = new JButton("\u25BC"); // ▼ arrow character
                    arrow.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                    arrow.setBorder(null);
                    arrow.setBackground(Color.WHITE);
                    arrow.setForeground(Color.GRAY);
                    arrow.setFocusPainted(false);
                    arrow.setContentAreaFilled(false);
                    arrow.setOpaque(false);
                    arrow.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    return arrow;
                }

                @Override
                public void paint(Graphics g, JComponent c) {
                    super.paint(g, c);
                    // Optional: extra background painting can go here
                }

                @Override
                protected void installDefaults() {
                    super.installDefaults();
                    comboBox.setBackground(Color.WHITE);
                    comboBox.setForeground(Color.DARK_GRAY);
                }
            });
        }
        
        private void styleTable(JTable table) {
            // Table header style
            JTableHeader header = table.getTableHeader();
            header.setFont(new Font("Segoe UI", Font.BOLD, 14));
            header.setBackground(new Color(230, 230, 230));
            header.setForeground(Color.DARK_GRAY);
            header.setReorderingAllowed(false);
            header.setResizingAllowed(false);
            header.setOpaque(true);

            // Table content style
            table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            table.setRowHeight(30);
            table.setShowGrid(true);
            table.setGridColor(new Color(220, 220, 220));
            table.setSelectionBackground(new Color(0, 123, 255));  // blue highlight
            table.setSelectionForeground(Color.WHITE);
            table.setForeground(Color.DARK_GRAY);
            table.setBackground(Color.WHITE);

            // Scroll pane border (if table is inside one)
            if (table.getParent() instanceof JViewport) {
                Container parent = table.getParent().getParent();
                if (parent instanceof JScrollPane) {
                    JScrollPane scrollPane = (JScrollPane) parent;
                    scrollPane.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true));
                }
            }
        }

        
        private void styleButtons() {
            styleButton(jButton1, new Color(39, 174, 96));   // Green - Add
            styleButton(jButton2, new Color(243, 156, 18));   // Yellow - Update
            styleButton(jButton3, new Color(231, 76, 60));   // Red - Delete
            styleButton(jButton4, new Color(52, 152, 219));   // Blue - Search
            jButton4.setPreferredSize(new Dimension(220, 45));
            jButton4.setMaximumSize(new Dimension (100, 30));
            jButton4.setMinimumSize(new Dimension(100, 30));
            jButton4.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
                @Override
                public void paint(Graphics g, JComponent c) {
                    AbstractButton b = (AbstractButton) c;
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(b.getBackground());
                    g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30); // Custom radius
                    g2.dispose();
                    super.paint(g, c);
                }
            });
        }

        private void styleButton(JButton button, Color baseColor) {
            button.setFont(new Font("Segoe UI", Font.BOLD, 14));
            button.setForeground(Color.WHITE);
            button.setBackground(baseColor);
            button.setFocusPainted(false);
            button.setContentAreaFilled(false);
            button.setOpaque(false);
            
            Dimension size = new Dimension(220, 40);
            button.setPreferredSize(size);
            button.setMinimumSize(size);
            button.setMaximumSize(size);
            
            button.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    button.setBackground(baseColor.brighter());
                    button.setForeground(Color.black);
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    button.setBackground(baseColor);
                    button.setForeground(Color.white);
                }
            });
            
            button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
                @Override
                public void paint(Graphics g, JComponent c) {
                    AbstractButton b = (AbstractButton) c;
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(b.getBackground());
                    g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 40, 40);
                    g2.dispose();
                    super.paint(g, c);
                }
            });
        }
        
        class RoundedBorder implements Border {
            private int radius;
            private Color borderColor;

            public RoundedBorder(int radius, Color borderColor) {
                this.radius = radius;
                this.borderColor = borderColor.darker();
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radius + 1, radius + 1, radius + 1, radius + 1);
            }

            @Override
            public boolean isBorderOpaque() {
                return false;
            }

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(borderColor);
                //g2d.setStroke(new BasicStroke(2));
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
                g2d.dispose();
            }
        }
        private void showCustomShipmentDialog(String productId, String location, String deliveryTime, String delays, String status) {
            String message = "Shipment Details\n\n"
                           + "Product ID: " + productId + "\n"
                           + "Location: " + location + "\n"
                           + "Estimated Delivery: " + deliveryTime + "\n"
                           + "Delays: " + delays + "\n"
                           + "Status: " + status;

            JTextArea textArea = new JTextArea(message);
            textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            textArea.setEditable(false);
            textArea.setOpaque(false);

            JOptionPane.showMessageDialog(null, textArea, "Shipment Information", JOptionPane.INFORMATION_MESSAGE);
        }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed

    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed

    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed

    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO tracking (product_id, location, estimated_delivery_time, delays, status) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, jTextField1.getText()); // Product ID
                pst.setString(2, jTextField2.getText()); // Location
                pst.setString(3, jTextField3.getText()); // ETA
                pst.setString(4, jTextField4.getText()); // Delays
                pst.setString(5, jComboBox1.getSelectedItem().toString()); // Status
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Shipment Added");
                loadTable();
            } catch (Exception e) {
                e.printStackTrace();
            }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

            try (Connection conn = DBConnection.getConnection()) {
                String query = "SELECT * FROM tracking WHERE product_id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, jTextField5.getText());
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    showCustomShipmentDialog(
                        rs.getString("product_id"),
                        rs.getString("location"),
                        rs.getString("estimated_delivery_time"),
                        rs.getString("delays"),
                        rs.getString("status")
                    );
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Product ID not found!");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "UPDATE tracking SET location=?, estimated_delivery_time=?, delays=?, status=? WHERE product_id=?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, jTextField2.getText());
                pst.setString(2, jTextField3.getText());
                pst.setString(3, jTextField4.getText());
                pst.setString(4, jComboBox1.getSelectedItem().toString());
                pst.setString(5, jTextField1.getText());
                int rows = pst.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(null, "Shipment Updated");
                    loadTable();
                } else {
                    JOptionPane.showMessageDialog(null, "Product ID not found");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "DELETE FROM tracking WHERE product_id=?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, jTextField1.getText());
                int rows = pst.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(null, "Shipment Deleted");
                    loadTable();
                } else {
                    JOptionPane.showMessageDialog(null, "Product ID not found");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }//GEN-LAST:event_jButton3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}