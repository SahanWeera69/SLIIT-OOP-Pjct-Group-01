package com.oshadha.main;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.GradientPaint;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.Box;
import javax.swing.BoxLayout;

import com.oshadha.panels.RoundedShadowPanel;
import AssignDrivers.AssignDrivers;
import Feedback.indexPage;
import ManageDelivery.ManageDeliveryPersonnel;
import avishka.report.MonthlyREport;
import customerNotifications.SendCustomerNotification;
import sathsara.SendNotificationForm.SendNotificationForm;
import scheduleDeliveries.DeliveryScheduler;
import shipment.ShipmentManager;


public class Dashboard extends javax.swing.JFrame {

    public Dashboard() {
        initComponents();
        
        styleDashboardPanels();
    }

    
    private void styleDashboardPanels() {
        stylePanel((RoundedShadowPanel) ScheduleDeliveries, "📅", new Color(52, 152, 219), "Schedule Deliveries");
        stylePanel((RoundedShadowPanel) CustomerNotifications, "🔔", new Color(46, 204, 113), "Customer Notifications");
        stylePanel((RoundedShadowPanel) ManageShipments, "📦️", new Color(241, 196, 15), "Manage Shipments");
        stylePanel((RoundedShadowPanel) ManageDeliveryPersonals, "🚚", new Color(155, 89, 182), "Manage Delivery Personnel");
        stylePanel((RoundedShadowPanel) SuggestDriverAssignments, "️👨‍️", new Color(231, 76, 60), "Assign Drivers to shipments");
        stylePanel((RoundedShadowPanel) DeliveryNotifications, "🚨️", new Color(52, 73, 94), "Delivery Personnel Notifications");
        stylePanel((RoundedShadowPanel) TrackShipments, "📍", new Color(149, 165, 166), "Track Shipments Process");
        stylePanel((RoundedShadowPanel) GenerateReports, "📊", new Color(230, 126, 34), "Monthly Reports");
        stylePanel((RoundedShadowPanel) FeedBack, "💬", new Color(26, 188, 156), "Feedback");
    }
    
    private void stylePanel(RoundedShadowPanel panel, String emoji, Color emojiColor, String labelText) {
        panel.setBackground(Color.WHITE);
        panel.setToolTipText(labelText);
        panel.setPreferredSize(new Dimension(160, 150)); // You can tweak this if needed
        panel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        panel.setCornerRadius(20);
        panel.setHoverBorderColor(emojiColor);

        // Panel to hold emoji and text vertically centered
        JPanel content = new JPanel(new GridBagLayout());
        content.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.anchor = GridBagConstraints.CENTER;

        // Emoji label
        JLabel iconLabel = new JLabel(emoji);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        iconLabel.setForeground(emojiColor);

        // Text label
        JLabel textLabel = new JLabel(labelText);
        textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        textLabel.setForeground(Color.DARK_GRAY);

        // Add components to content panel
        gbc.gridy = 0;
        content.add(iconLabel, gbc);
        gbc.gridy = 1;
        content.add(textLabel, gbc);

        // Add content panel to the center of the rounded panel
        panel.setLayout(new BorderLayout());
        panel.removeAll();
        panel.add(content, BorderLayout.CENTER);

        // Optional: click behavior
//        panel.addMouseListener(new MouseAdapter() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                JOptionPane.showMessageDialog(null, labelText + " clicked!");
//            }
//        });

        panel.revalidate();
        panel.repaint();
    }

    private void addHoverEffect(JPanel panel, Color hoverBorderColor, int cornerRadius) {
        Color originalBackground = panel.getBackground();
        Border originalBorder = panel.getBorder();

        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Border shadowBorder = BorderFactory.createMatteBorder(2, 2, 8, 8, new Color(0, 0, 0, 30));
                Border roundedBorder = BorderFactory.createLineBorder(hoverBorderColor, 2, true); // true = rounded

                Border combined = BorderFactory.createCompoundBorder(shadowBorder, roundedBorder);
                panel.setBorder(combined);

                panel.setBackground(originalBackground.darker());
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panel.setBorder(originalBorder);
                panel.setBackground(originalBackground);
            }
        });
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ScheduleDeliveries = new com.oshadha.panels.RoundedShadowPanel();
        CustomerNotifications = new com.oshadha.panels.RoundedShadowPanel();
        ManageShipments = new com.oshadha.panels.RoundedShadowPanel();
        ManageDeliveryPersonals = new com.oshadha.panels.RoundedShadowPanel();
        SuggestDriverAssignments = new com.oshadha.panels.RoundedShadowPanel();
        DeliveryNotifications = new com.oshadha.panels.RoundedShadowPanel();
        TrackShipments = new com.oshadha.panels.RoundedShadowPanel();
        GenerateReports = new com.oshadha.panels.RoundedShadowPanel();
        FeedBack = new com.oshadha.panels.RoundedShadowPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("FastTrack LOGISTICS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel2.setLayout(new java.awt.GridLayout(3, 3, 20, 20));

        ScheduleDeliveries.setPreferredSize(new java.awt.Dimension(339, 178));
        ScheduleDeliveries.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ScheduleDeliveriesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout ScheduleDeliveriesLayout = new javax.swing.GroupLayout(ScheduleDeliveries);
        ScheduleDeliveries.setLayout(ScheduleDeliveriesLayout);
        ScheduleDeliveriesLayout.setHorizontalGroup(
            ScheduleDeliveriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        ScheduleDeliveriesLayout.setVerticalGroup(
            ScheduleDeliveriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.add(ScheduleDeliveries);

        CustomerNotifications.setPreferredSize(new java.awt.Dimension(339, 178));
        CustomerNotifications.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerNotificationsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout CustomerNotificationsLayout = new javax.swing.GroupLayout(CustomerNotifications);
        CustomerNotifications.setLayout(CustomerNotificationsLayout);
        CustomerNotificationsLayout.setHorizontalGroup(
            CustomerNotificationsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        CustomerNotificationsLayout.setVerticalGroup(
            CustomerNotificationsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.add(CustomerNotifications);

        ManageShipments.setForeground(new java.awt.Color(255, 255, 255));
        ManageShipments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ManageShipmentsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout ManageShipmentsLayout = new javax.swing.GroupLayout(ManageShipments);
        ManageShipments.setLayout(ManageShipmentsLayout);
        ManageShipmentsLayout.setHorizontalGroup(
            ManageShipmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        ManageShipmentsLayout.setVerticalGroup(
            ManageShipmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(ManageShipments);

        ManageDeliveryPersonals.setPreferredSize(new java.awt.Dimension(339, 178));
        ManageDeliveryPersonals.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ManageDeliveryPersonalsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout ManageDeliveryPersonalsLayout = new javax.swing.GroupLayout(ManageDeliveryPersonals);
        ManageDeliveryPersonals.setLayout(ManageDeliveryPersonalsLayout);
        ManageDeliveryPersonalsLayout.setHorizontalGroup(
            ManageDeliveryPersonalsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        ManageDeliveryPersonalsLayout.setVerticalGroup(
            ManageDeliveryPersonalsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(ManageDeliveryPersonals);

        SuggestDriverAssignments.setPreferredSize(new java.awt.Dimension(339, 178));
        SuggestDriverAssignments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SuggestDriverAssignmentsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout SuggestDriverAssignmentsLayout = new javax.swing.GroupLayout(SuggestDriverAssignments);
        SuggestDriverAssignments.setLayout(SuggestDriverAssignmentsLayout);
        SuggestDriverAssignmentsLayout.setHorizontalGroup(
            SuggestDriverAssignmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        SuggestDriverAssignmentsLayout.setVerticalGroup(
            SuggestDriverAssignmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(SuggestDriverAssignments);

        DeliveryNotifications.setPreferredSize(new java.awt.Dimension(339, 178));
        DeliveryNotifications.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeliveryNotificationsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout DeliveryNotificationsLayout = new javax.swing.GroupLayout(DeliveryNotifications);
        DeliveryNotifications.setLayout(DeliveryNotificationsLayout);
        DeliveryNotificationsLayout.setHorizontalGroup(
            DeliveryNotificationsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        DeliveryNotificationsLayout.setVerticalGroup(
            DeliveryNotificationsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(DeliveryNotifications);

        TrackShipments.setPreferredSize(new java.awt.Dimension(339, 178));
        TrackShipments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TrackShipmentsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout TrackShipmentsLayout = new javax.swing.GroupLayout(TrackShipments);
        TrackShipments.setLayout(TrackShipmentsLayout);
        TrackShipmentsLayout.setHorizontalGroup(
            TrackShipmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        TrackShipmentsLayout.setVerticalGroup(
            TrackShipmentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(TrackShipments);

        GenerateReports.setPreferredSize(new java.awt.Dimension(339, 178));
        GenerateReports.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GenerateReportsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout GenerateReportsLayout = new javax.swing.GroupLayout(GenerateReports);
        GenerateReports.setLayout(GenerateReportsLayout);
        GenerateReportsLayout.setHorizontalGroup(
            GenerateReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        GenerateReportsLayout.setVerticalGroup(
            GenerateReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(GenerateReports);

        FeedBack.setPreferredSize(new java.awt.Dimension(339, 178));
        FeedBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FeedBackMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout FeedBackLayout = new javax.swing.GroupLayout(FeedBack);
        FeedBack.setLayout(FeedBackLayout);
        FeedBackLayout.setHorizontalGroup(
            FeedBackLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FeedBackLayout.setVerticalGroup(
            FeedBackLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );

        jPanel2.add(FeedBack);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ManageShipmentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ManageShipmentsMouseClicked
        new ShipmentManager().setVisible(true);
    }//GEN-LAST:event_ManageShipmentsMouseClicked

    private void CustomerNotificationsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerNotificationsMouseClicked
        new SendCustomerNotification().setVisible(true);
    }//GEN-LAST:event_CustomerNotificationsMouseClicked

    private void ScheduleDeliveriesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ScheduleDeliveriesMouseClicked
        new DeliveryScheduler().setVisible(true);
    }//GEN-LAST:event_ScheduleDeliveriesMouseClicked

    private void SuggestDriverAssignmentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SuggestDriverAssignmentsMouseClicked
        new AssignDrivers().setVisible(true);
    }//GEN-LAST:event_SuggestDriverAssignmentsMouseClicked

    private void FeedBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FeedBackMouseClicked
        new indexPage().setVisible(true); 
    }//GEN-LAST:event_FeedBackMouseClicked

    private void ManageDeliveryPersonalsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ManageDeliveryPersonalsMouseClicked
        new ManageDeliveryPersonnel().setVisible(true);
    }//GEN-LAST:event_ManageDeliveryPersonalsMouseClicked

    private void TrackShipmentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TrackShipmentsMouseClicked
        new Main().setVisible(true);
    }//GEN-LAST:event_TrackShipmentsMouseClicked

    private void GenerateReportsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GenerateReportsMouseClicked
        new MonthlyREport().setVisible(true);
    }//GEN-LAST:event_GenerateReportsMouseClicked

    private void DeliveryNotificationsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeliveryNotificationsMouseClicked
        new SendNotificationForm().setVisible(true);
    }//GEN-LAST:event_DeliveryNotificationsMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CustomerNotifications;
    private javax.swing.JPanel DeliveryNotifications;
    private javax.swing.JPanel FeedBack;
    private javax.swing.JPanel GenerateReports;
    private javax.swing.JPanel ManageDeliveryPersonals;
    private javax.swing.JPanel ManageShipments;
    private javax.swing.JPanel ScheduleDeliveries;
    private javax.swing.JPanel SuggestDriverAssignments;
    private javax.swing.JPanel TrackShipments;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
