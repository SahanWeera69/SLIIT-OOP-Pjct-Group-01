package shipment;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Cursor;

import com.oshadha.main.Dashboard;
import java.awt.Window;

public class ShipmentManager extends JFrame {
    JTextField txtSender, txtReceiver, txtPackage, txtStatus;
    JButton btnAdd, btnUpdate, btnDelete;
    JTable table;
    DefaultTableModel model;

    public ShipmentManager() {
        setTitle("Shipment Manager");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // TOP HEADER PANEL
        JPanel headerPanel = new JPanel();
        headerPanel.setBounds(0, 0, 700, 60);
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(241, 196, 15));
        add(headerPanel);

        // Title
        JLabel titleLabel = new JLabel("Shipment Management");
        titleLabel.setForeground(new Color(255, 255, 255));
        titleLabel.setFont(new Font("Roboto", Font.BOLD, 24));
        titleLabel.setBounds(200, 15, 700, 30);
        headerPanel.add(titleLabel);
        
        // BACK TO DASHBOARD LABEL
        JLabel lblBackToDashboard = new JLabel("🔙");
        lblBackToDashboard.setFont(new Font("Segoe UI Emoji", Font.BOLD, 24));
        lblBackToDashboard.setForeground(new Color(255, 255, 255)); // Dodger blue
        lblBackToDashboard.setBounds(20, 15, 200, 30);
        lblBackToDashboard.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        lblBackToDashboard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Window window = SwingUtilities.getWindowAncestor(lblBackToDashboard);
                window.dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblBackToDashboard.setForeground(new Color(48,128,185)); // hover color
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblBackToDashboard.setForeground(new Color(255, 255, 255)); // normal color
            }
        });

        headerPanel.add(lblBackToDashboard);

        

        // FORM COMPONENTS
        // Row 1: Sender and Receiver
        JLabel send = new JLabel("Sender");
        send.setBounds(20, 80, 100, 25); // y changed from 40 → 80
        add(send);
        txtSender = new JTextField();
        txtSender.setBounds(100, 80, 150, 25);
        add(txtSender);

        JLabel rec = new JLabel("Receiver");
        rec.setBounds(270, 80, 100, 25); // y changed from 40 → 80
        add(rec);
        txtReceiver = new JTextField();
        txtReceiver.setBounds(350, 80, 150, 25);
        add(txtReceiver);

        // Row 2: Package and Status
        JLabel pack = new JLabel("Package");
        pack.setBounds(20, 120, 100, 25); // y changed from 80 → 120
        add(pack);
        txtPackage = new JTextField();
        txtPackage.setBounds(100, 120, 150, 25);
        add(txtPackage);

        JLabel sta = new JLabel("Status");
        sta.setBounds(270, 120, 100, 25); // y changed from 80 → 120
        add(sta);
        txtStatus = new JTextField();
        txtStatus.setBounds(350, 120, 150, 25);
        add(txtStatus);

        // Row 3: Buttons
        btnAdd = new JButton("Add");
        btnAdd.setBackground(new Color(255, 255, 255));
        btnAdd.setBounds(100, 170, 100, 30); // y changed from 130 → 170
        add(btnAdd);

        btnUpdate = new JButton("Update");
        btnUpdate.setBackground(new Color(255, 255, 255));
        btnUpdate.setBounds(220, 170, 100, 30);
        add(btnUpdate);

        btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(255, 255, 255));
        btnDelete.setBounds(340, 170, 100, 30);
        add(btnDelete);

        // Table below buttons

        model = new DefaultTableModel(new String[] { "ID", "Sender", "Receiver", "Package", "Status" }, 0);
        table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 220, 650, 180); // y changed from 260 → 220
        add(pane);

        loadData();

        btnAdd.addActionListener(e -> addShipment());
        btnUpdate.addActionListener(e -> updateShipment());
        btnDelete.addActionListener(e -> deleteShipment());
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtSender.setText(model.getValueAt(row, 1).toString());
                txtReceiver.setText(model.getValueAt(row, 2).toString());
                txtPackage.setText(model.getValueAt(row, 3).toString());
                txtStatus.setText(model.getValueAt(row, 4).toString());
            }
        });

        getContentPane().setBackground(new Color(245, 245, 245));

        setVisible(true);
    }

    final void loadData() {
        try (Connection con = DBConnection.getConnection()) {
            model.setRowCount(0);
            PreparedStatement pst = con.prepareStatement("SELECT * FROM shipment");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("id"), 
                        rs.getString("sender"),
                        rs.getString("receiver"),
                        rs.getString("package_details"),
                        rs.getString("status")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void addShipment() {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                    "INSERT INTO shipment (sender, receiver, package_details, status) VALUES (?, ?, ?, ?)");
            pst.setString(1, txtSender.getText());
            pst.setString(2, txtReceiver.getText());
            pst.setString(3, txtPackage.getText());
            pst.setString(4, txtStatus.getText());
            pst.executeUpdate();
            loadData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void updateShipment() {
        int row = table.getSelectedRow();
        if (row == -1)
            return;
        int id = (int) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                    "UPDATE shipment SET sender=?, receiver=?, package_details=?, status=? WHERE id=?");
            pst.setString(1, txtSender.getText());
            pst.setString(2, txtReceiver.getText());
            pst.setString(3, txtPackage.getText());
            pst.setString(4, txtStatus.getText());
            pst.setInt(5, id);
            pst.executeUpdate();
            loadData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void deleteShipment() {
        int row = table.getSelectedRow();
        if (row == -1)
            return;
        int id = (int) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("DELETE FROM shipment WHERE id=?");
            pst.setInt(1, id);
            pst.executeUpdate();
            loadData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ShipmentManager shipmentManager = new ShipmentManager();
    }
}