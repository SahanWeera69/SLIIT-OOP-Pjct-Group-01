
package shipment;

public class Shipment {
    private int id;
    private String sender;
    private String receiver;
    private String packageDetails;
    private String status;
    
    public Shipment(int id, String sender, String receiver, String packageDetails, String status) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.packageDetails = packageDetails;
        this.status = status;
}
}
