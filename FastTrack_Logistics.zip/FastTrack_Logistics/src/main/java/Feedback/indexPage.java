/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Feedback;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import com.oshadha.main.Dashboard;

public class indexPage extends javax.swing.JFrame {

    public indexPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        mainPanel = new javax.swing.JPanel();
        optionPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        selectPanel = new javax.swing.JPanel();
        statusLabel = new javax.swing.JLabel();
        shipmentIdtxtField = new javax.swing.JTextField();
        idLabel = new javax.swing.JLabel();
        ratingComboBox = new javax.swing.JComboBox<>();
        ratingLabel1 = new javax.swing.JLabel();
        deliveryComboBox = new javax.swing.JComboBox<>();
        searchBtn = new javax.swing.JButton();
        viewPanel = new javax.swing.JPanel();
        viewBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        RefreshBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        mainmenubtn = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainPanel.setBackground(new java.awt.Color(0, 102, 102));
        mainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        optionPanel.setBackground(new java.awt.Color(0, 51, 51));
        optionPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 36)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(0, 255, 255));
        titleLabel.setText("Feedback and Reviews");
        optionPanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, 40));

        selectPanel.setBackground(new java.awt.Color(0, 153, 153));
        selectPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Select Options", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Trebuchet MS", 1, 18), new java.awt.Color(0, 255, 255))); // NOI18N
        selectPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        statusLabel.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        statusLabel.setForeground(new java.awt.Color(51, 255, 255));
        statusLabel.setText("Delivery Status :");
        selectPanel.add(statusLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        shipmentIdtxtField.setBackground(new java.awt.Color(153, 255, 255));
        shipmentIdtxtField.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        shipmentIdtxtField.setForeground(new java.awt.Color(0, 102, 102));
        shipmentIdtxtField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        shipmentIdtxtField.setToolTipText("Enter Shipment ID");
        shipmentIdtxtField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shipmentIdtxtFieldActionPerformed(evt);
            }
        });
        selectPanel.add(shipmentIdtxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 160, 30));

        idLabel.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        idLabel.setForeground(new java.awt.Color(51, 255, 255));
        idLabel.setText("Shipment ID :");
        selectPanel.add(idLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        ratingComboBox.setBackground(new java.awt.Color(153, 255, 255));
        ratingComboBox.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ratingComboBox.setForeground(new java.awt.Color(0, 102, 102));
        ratingComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- none -", "1", "2", "3", "4", "5" }));
        ratingComboBox.setToolTipText("Select a rating");
        ratingComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ratingComboBoxActionPerformed(evt);
            }
        });
        selectPanel.add(ratingComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 160, 30));

        ratingLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        ratingLabel1.setForeground(new java.awt.Color(51, 255, 255));
        ratingLabel1.setText("Rating :");
        selectPanel.add(ratingLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        deliveryComboBox.setBackground(new java.awt.Color(153, 255, 255));
        deliveryComboBox.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        deliveryComboBox.setForeground(new java.awt.Color(0, 102, 102));
        deliveryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- none -", "Delivered", "On-Delivery", "Returned", "Failed" }));
        deliveryComboBox.setToolTipText("Select Delivery Status");
        deliveryComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deliveryComboBoxActionPerformed(evt);
            }
        });
        selectPanel.add(deliveryComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 160, 30));

        searchBtn.setBackground(new java.awt.Color(0, 255, 255));
        searchBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchBtn.setForeground(new java.awt.Color(0, 102, 102));
        searchBtn.setText("Search");
        searchBtn.setToolTipText("Search Reviews");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });
        selectPanel.add(searchBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 258, 330, -1));

        optionPanel.add(selectPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 370, 310));
        selectPanel.getAccessibleContext().setAccessibleDescription("");

        viewPanel.setBackground(new java.awt.Color(0, 153, 153));
        viewPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View Reviews", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Trebuchet MS", 1, 18), new java.awt.Color(0, 255, 255))); // NOI18N
        viewPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        viewBtn.setBackground(new java.awt.Color(0, 255, 255));
        viewBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewBtn.setForeground(new java.awt.Color(0, 102, 102));
        viewBtn.setText("View");
        viewBtn.setToolTipText("View Current Feedback");
        viewBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewBtnActionPerformed(evt);
            }
        });
        viewPanel.add(viewBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 320, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 255, 255));
        jLabel1.setText("Select a Feedback and click \"View\" Button.");
        viewPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 290, -1));

        optionPanel.add(viewPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 370, 190));

        RefreshBtn.setBackground(new java.awt.Color(0, 204, 204));
        RefreshBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        RefreshBtn.setForeground(new java.awt.Color(0, 51, 51));
        RefreshBtn.setText("Refresh Page");
        RefreshBtn.setToolTipText("Refresh the page for new");
        RefreshBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshBtnActionPerformed(evt);
            }
        });
        optionPanel.add(RefreshBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 650, 140, 40));

        mainPanel.add(optionPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 390, 710));

        jScrollPane1.setBackground(new java.awt.Color(0, 204, 204));

        jTable1.setBackground(new java.awt.Color(0, 153, 153));
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jTable1.setForeground(new java.awt.Color(153, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Shipment_ID", "DelivaryStatus", "DateDelivery", "Rating", "CustomerReview", "AdminReply"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setGridColor(new java.awt.Color(0, 153, 153));
        jTable1.setRowHeight(50);
        jScrollPane1.setViewportView(jTable1);

        mainPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 20, 1060, 760));

        mainmenubtn.setBackground(new java.awt.Color(0, 102, 102));
        mainmenubtn.setFont(new java.awt.Font("Segoe UI Emoji", 0, 40)); // NOI18N
        mainmenubtn.setForeground(new java.awt.Color(255, 255, 255));
        mainmenubtn.setText("🔙 ");
        mainmenubtn.setToolTipText("Go back to Dashboard");
        mainmenubtn.setBorderPainted(false);
        mainmenubtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainmenubtnMouseClicked(evt);
            }
        });
        mainmenubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainmenubtnActionPerformed(evt);
            }
        });
        mainPanel.add(mainmenubtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 140, 70));

        getContentPane().add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mainmenubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainmenubtnActionPerformed
        this.dispose(); // close the indexpage
    }//GEN-LAST:event_mainmenubtnActionPerformed

    private void shipmentIdtxtFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shipmentIdtxtFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_shipmentIdtxtFieldActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        String shipmentID = shipmentIdtxtField.getText().trim();
        String rating = (String) ratingComboBox.getSelectedItem();
        String deliveryStatus = (String) deliveryComboBox.getSelectedItem();

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear previous rows

        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Failed to connect to the database.");
                return;
            }

            Statement stmt = conn.createStatement();

            // Start query
            String query = "SELECT * FROM reviews WHERE 1=1";

            // Add filters only if user input is given
            if (!shipmentID.isEmpty()) {
                query += " AND Shipment_ID = '" + shipmentID + "'";
            }

            if (rating != null && !rating.equals("- none -")) {
                query += " AND Rating = " + rating;
            }

            if (deliveryStatus != null && !deliveryStatus.equals("- none -")) {
                query += " AND DeliveryStatus = '" + deliveryStatus + "'";
            }

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Shipment_ID"),
                    rs.getString("DeliveryStatus"),
                    rs.getString("DateDelivery"),
                    rs.getInt("Rating"),
                    rs.getString("CustomerReview"),
                    rs.getString("AdminReply")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_searchBtnActionPerformed

    private void viewBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewBtnActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to view.");
            return;
        }

        // Get data from selected row
        String shipmentID = jTable1.getValueAt(selectedRow, 0).toString();
        String rating = jTable1.getValueAt(selectedRow, 3).toString();
        String customerReview = jTable1.getValueAt(selectedRow, 4).toString();
        String adminReply = jTable1.getValueAt(selectedRow, 5).toString();

        // Open ShowReviews with selected row data
        ShowReviews sr = new ShowReviews(shipmentID, rating, customerReview, adminReply);
        sr.setVisible(true);
    }//GEN-LAST:event_viewBtnActionPerformed

    private void deliveryComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deliveryComboBoxActionPerformed
        searchBtnActionPerformed(null);
    }//GEN-LAST:event_deliveryComboBoxActionPerformed

    private void ratingComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ratingComboBoxActionPerformed
        searchBtnActionPerformed(null);
    }//GEN-LAST:event_ratingComboBoxActionPerformed

    private void RefreshBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshBtnActionPerformed
        String shipmentID = shipmentIdtxtField.getText().trim();
        String rating = (String) ratingComboBox.getSelectedItem();
        String deliveryStatus = (String) deliveryComboBox.getSelectedItem();

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear previous rows

        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Failed to connect to the database.");
                return;
            }

            Statement stmt = conn.createStatement();

            // Start query
            String query = "SELECT * FROM reviews WHERE 1=1";

            // Add filters only if user input is given
            if (!shipmentID.isEmpty()) {
                query += " AND Shipment_ID = '" + shipmentID + "'";
            }

            if (rating != null && !rating.equals("- none -")) {
                query += " AND Rating = " + rating;
            }

            if (deliveryStatus != null && !deliveryStatus.equals("- none -")) {
                query += " AND DeliveryStatus = '" + deliveryStatus + "'";
            }

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Shipment_ID"),
                    rs.getString("DeliveryStatus"),
                    rs.getString("DateDelivery"),
                    rs.getInt("Rating"),
                    rs.getString("CustomerReview"),
                    rs.getString("AdminReply")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_RefreshBtnActionPerformed

    private void mainmenubtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainmenubtnMouseClicked
        new Dashboard().setVisible(true);
    }//GEN-LAST:event_mainmenubtnMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new indexPage().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton RefreshBtn;
    private javax.swing.JComboBox<String> deliveryComboBox;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton mainmenubtn;
    private javax.swing.JPanel optionPanel;
    private javax.swing.JComboBox<String> ratingComboBox;
    private javax.swing.JLabel ratingLabel1;
    private javax.swing.JButton searchBtn;
    private javax.swing.JPanel selectPanel;
    private javax.swing.JTextField shipmentIdtxtField;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JButton viewBtn;
    private javax.swing.JPanel viewPanel;
    // End of variables declaration//GEN-END:variables
}
