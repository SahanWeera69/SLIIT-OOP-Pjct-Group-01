package avishka.report;

import javax.swing.JOptionPane;
import java.util.Map;
import java.util.HashMap;
import java.text.DecimalFormat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MonthlyREport extends javax.swing.JFrame {

    public MonthlyREport() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        year = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        month = new javax.swing.JComboBox<>();
        button = new javax.swing.JButton();
        reportArea = new java.awt.TextArea();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel2.setText("Year");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, -1, -1));

        year.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Year", "2023", "2024", "2025" }));
        year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearActionPerformed(evt);
            }
        });
        jPanel1.add(year, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 120, -1));

        jLabel3.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel3.setText("Month");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 50, -1));

        month.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Month", "January ", "February", "March", "April", "May", "June", "July", "Auguest", "September", "October", "November", "December" }));
        jPanel1.add(month, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 120, -1));

        button.setBackground(new java.awt.Color(153, 255, 153));
        button.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        button.setText("Genarate Report");
        button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActionPerformed(evt);
            }
        });
        jPanel1.add(button, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 230, 130, 30));

        reportArea.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        jPanel1.add(reportArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 600, 270));

        jPanel2.setBackground(new java.awt.Color(230, 126, 34));

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Generate Monthly Report");

        jButton1.setBackground(new java.awt.Color(230, 126, 34));
        jButton1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 40)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("🔙 ");
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(195, 195, 195))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void yearActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_yearActionPerformed
        // TODO add your handling code here:
    }// GEN-LAST:event_yearActionPerformed

    private void buttonActionPerformed(java.awt.event.ActionEvent evt) {
        String selectedYear = (String) year.getSelectedItem();
        String selectedMonth = (String) month.getSelectedItem();

        // Validate selection
        if ("Select Year".equals(selectedYear)) {
            JOptionPane.showMessageDialog(this,
                    "Please select a year",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if ("Select Month".equals(selectedMonth)) {
            JOptionPane.showMessageDialog(this,
                    "Please select a month",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int yearValue = Integer.parseInt(selectedYear);

            // Get report data from DatabaseHandler
            Map<String, Object> reportData = DatabaseHandler.generateMonthlyReport(yearValue, selectedMonth);

            // Format the report
            StringBuilder report = new StringBuilder();
            DecimalFormat currencyFormat = new DecimalFormat("$#,##0.00");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentDateTime = dateFormat.format(new Date());

            report.append(String.format("                         ========= Monthly Report (%s %d) =========\n\n",
                    selectedMonth, yearValue));

            report.append(String.format("%-20s: %d\n",
                    "          Total Deliveries",
                    (int) reportData.get("totalDeliveries")));

            report.append(String.format("%-20s: %d\n",
                    "          Total Quantity Shipped",
                    (int) reportData.get("totalQuantity")));

            report.append(String.format("%-20s: %s\n",
                    "          Total Revenue",
                    currencyFormat.format((double) reportData.get("totalRevenue"))));

            report.append(String.format("%-20s: %s\n",
                    "          Total Expenses",
                    currencyFormat.format((double) reportData.get("totalExpenses"))));

            report.append(String.format("%-20s: %s\n\n",
                    "          Net Profit",
                    currencyFormat.format(
                            (double) reportData.get("totalRevenue") -
                                    (double) reportData.get("totalExpenses"))));

            // Status breakdown
            report.append("          Status Breakdown:\n");
            Map<String, Integer> statusBreakdown = (Map<String, Integer>) reportData.get("statusBreakdown");

            for (Map.Entry<String, Integer> entry : statusBreakdown.entrySet()) {
                report.append(String.format("           - %-10s: %d\n",
                        entry.getKey(),
                        entry.getValue()));
            }

            // Report footer
            report.append(String.format("\n%-20s: %s\n",
                    "           Report Generated On",
                    currentDateTime));
            report.append("\n                       ============================================");

            // Display the report
            reportArea.setText(report.toString());

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Invalid year format",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error generating report: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MonthlyREport.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MonthlyREport.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MonthlyREport.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MonthlyREport.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        }
        // </editor-fold>
        // </editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MonthlyREport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton button;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> month;
    private java.awt.TextArea reportArea;
    private javax.swing.JComboBox<String> year;
    // End of variables declaration//GEN-END:variables
}
