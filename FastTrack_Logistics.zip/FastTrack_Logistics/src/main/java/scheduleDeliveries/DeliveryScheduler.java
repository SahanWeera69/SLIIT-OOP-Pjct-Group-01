package scheduleDeliveries;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import scheduleDeliveries.DeliverySlot;
import scheduleDeliveries.ScheduledDelivery;

public class DeliveryScheduler extends JFrame {
    private final List<DeliverySlot> availableSlots;
    private final List<ScheduledDelivery> scheduledDeliveries;
    
    private JComboBox<DeliverySlot> slotComboBox;
    private JTextField customerField;
    private JTextField packageField;
    private JTextField shipmentID;
    private JTextArea outputArea;

    public DeliveryScheduler() {
        availableSlots = new ArrayList<>();
        scheduledDeliveries = new ArrayList<>();
        initializeSampleSlots();
        
        setTitle("Delivery Scheduling System");
        setSize(400, 500); // Adjusted size for better layout
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setupUI();
    }

    private void initializeSampleSlots() {
        availableSlots.add(new DeliverySlot("Morning (8AM-12PM)"));
        availableSlots.add(new DeliverySlot("Afternoon (1PM-5PM)"));
        availableSlots.add(new DeliverySlot("Evening (5PM-9PM)"));
    }

    private void setupUI() {
        // Main panel with vertical BoxLayout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ===== Header Panel =====
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(52, 152, 219)); // panel color
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Centered Title (White)
        JLabel titleLabel = new JLabel("Schedule Deliveries", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Dialog", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);

        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerPanel.setOpaque(false); // Make sure background is transparent to show headerPanel color
        centerPanel.add(titleLabel);
        headerPanel.add(centerPanel, BorderLayout.CENTER);

        // "Go Back" label - Right aligned, light blue
        JLabel goBackLabel = new JLabel("🔙");
        goBackLabel.setFont(new Font("Segoe UI Emoji",Font.PLAIN, 36));
        goBackLabel.setForeground(new Color(255, 255, 255)); // Light Blue
        goBackLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        goBackLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); // Close the window
            }
        });

        JPanel eastPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        eastPanel.setOpaque(false);
        eastPanel.add(goBackLabel);
        headerPanel.add(eastPanel, BorderLayout.WEST);

        mainPanel.add(headerPanel);

        // ===== Delivery Slot =====
        JPanel slotPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        slotPanel.add(new JLabel("Delivery Slot:"));
        slotComboBox = new JComboBox<>(availableSlots.toArray(new DeliverySlot[0]));
        slotPanel.add(slotComboBox);
        mainPanel.add(slotPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // ===== Customer Name =====
        JPanel customerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        customerPanel.add(new JLabel("Customer Name:"));
        customerField = new JTextField(20);
        customerPanel.add(customerField);
        mainPanel.add(customerPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // ===== Shipment ID =====
        JPanel shipmentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        shipmentPanel.add(new JLabel("Shipment ID:"));
        shipmentID = new JTextField(20);
        shipmentPanel.add(shipmentID);
        mainPanel.add(shipmentPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // ===== Package Details =====
        JPanel packagePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        packagePanel.add(new JLabel("Package Details:"));
        packageField = new JTextField(20);
        packagePanel.add(packageField);
        mainPanel.add(packagePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // ===== Buttons =====
        JPanel buttonPanel = new JPanel();
        JButton scheduleBtn = new JButton("Schedule Delivery");
        scheduleBtn.addActionListener(this::handleSchedule);
        JButton viewBtn = new JButton("View All Bookings");
        viewBtn.addActionListener(this::handleViewBookings);
        buttonPanel.add(scheduleBtn);
        buttonPanel.add(viewBtn);
        mainPanel.add(buttonPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // ===== Output Area =====
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        mainPanel.add(scrollPane);

        add(mainPanel);
    }

    private void handleSchedule(ActionEvent e) {
        String customer = customerField.getText().trim();
        String pkgDetails = packageField.getText().trim();
        String shipment = shipmentID.getText().trim();
        
        if (customer.isEmpty() || pkgDetails.isEmpty() || shipment.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please fill in all fields", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        DeliverySlot selectedSlot = (DeliverySlot) slotComboBox.getSelectedItem();
        ScheduledDelivery newDelivery = new ScheduledDelivery(customer, pkgDetails, selectedSlot);
        
        scheduledDeliveries.add(newDelivery);
        outputArea.append("Scheduled Delivery:\n");
        outputArea.append("Customer: " + customer + "\n");
        outputArea.append("Shipment ID: " + shipment + "\n");
        outputArea.append("Time Slot: " + selectedSlot.getTimeRange() + "\n");
        outputArea.append("Package: " + pkgDetails + "\n\n");
        
        customerField.setText("");
        packageField.setText("");
        shipmentID.setText("");
    }

    private void handleViewBookings(ActionEvent e) {
        if (scheduledDeliveries.isEmpty()) {
            outputArea.setText("No deliveries scheduled yet.");
            return;
        }
        
        outputArea.setText("Current Bookings:\n");
        for (int i = 0; i < scheduledDeliveries.size(); i++) {
            ScheduledDelivery d = scheduledDeliveries.get(i);
            outputArea.append("Booking #" + (i+1) + "\n");
            outputArea.append("Customer: " + d.getCustomerName() + "\n");
            outputArea.append("Time Slot: " + d.getSlot().getTimeRange() + "\n");
            outputArea.append("Package: " + d.getPackageDetails() + "\n\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DeliveryScheduler scheduler = new DeliveryScheduler();
            scheduler.setVisible(true);
        });
    }
}