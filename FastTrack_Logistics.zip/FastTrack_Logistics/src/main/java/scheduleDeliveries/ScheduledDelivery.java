package scheduleDeliveries;

public class ScheduledDelivery {
    private final String customerName;
    private final String packageDetails;
    private final DeliverySlot slot;

    public ScheduledDelivery(String customerName, String packageDetails, DeliverySlot slot) {
        this.customerName = customerName;
        this.packageDetails = packageDetails;
        this.slot = slot;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getPackageDetails() {
        return packageDetails;
    }

    public DeliverySlot getSlot() {
        return slot;
    }
}